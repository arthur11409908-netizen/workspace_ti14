let Media
let nota1
let nota2
let nota3 

Media = prompt(" INFORME A MEDIA DE UM ALUNO")
nota = prompt (" INFORME A NOTA DE UM ALUNO")
